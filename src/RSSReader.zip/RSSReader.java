
import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;
import java.net.*;
import java.util.*;
import org.jsoup.Jsoup;



import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Scanner;

public class RSSReader {

    private static final int MAX_ITEMS = 10; // Define maximum number of RSS items to display

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        boolean isRunning = true;
        while (isRunning) {
            System.out.println("1. Add Website\n2. Delete Website\n3. Display Websites\n4. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addWebsite();
                    break;
                case 2:
                    deleteWebsite();
                    break;
                case 3:
                    displayWebsites();
                    break;
                case 4:
                    saveWebsites();
                    System.out.println("Exiting program...");
                    isRunning = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 4.");
            }
        }

        scanner.close();
    }

    private static ArrayList< String[]> websitesList = new ArrayList<>();

    private static void addWebsite() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter website name: ");
        String name = scanner.nextLine();
        System.out.print("Enter website address: ");
        String address = scanner.nextLine();
        System.out.print("Enter RSS address: ");
        String rssAddress = scanner.nextLine();

        String[] websiteInfo = {name, address, rssAddress};
        websitesList.add(websiteInfo);

        System.out.println("Website added successfully!");
    }

    private static void deleteWebsite() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the name of the website to delete: ");
        String nameToDelete = scanner.nextLine();

        boolean found = false;
        for (String[] website : websitesList) {
            if (website[0].equalsIgnoreCase(nameToDelete)) {
                websitesList.remove(website);
                found = true;
                System.out.println("Website deleted successfully!");
                break;
            }
        }

        if (!found) {
            System.out.println("Website not found.");
        }
    }

    private static void displayWebsites() {
        if (websitesList.isEmpty()) {
            System.out.println("No websites added yet.");
        } else {
            System.out.println("List of added websites:");
            for (String[] website : websitesList) {
                System.out.println("Name: " + website[0]);
                System.out.println("Address: " + website[1]);
                System.out.println("RSS Address: " + website[2]);
                System.out.println("--------------------");
            }
        }
    }

    private static void saveWebsites() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("websites.txt"))) {
            for (String[] website : websitesList) {
                writer.write(website[0] + "," + website[1] + "," + website[2]);
                writer.newLine();
            }
            System.out.println("Websites saved to file successfully!");
        } catch (IOException e) {
            System.out.println("Error saving websites to file: " + e.getMessage());
        }
    }

    public static String extractPageTitle(String html) {
        try {
            Document doc = Jsoup.parse(html);
            return doc.title();
        } catch (Exception e) {
            return "Error: no title tag found in page source!";
        }
    }

    public static void retrieveRssContent(String rssUrl) {
        try {
            String rssXml = fetchPageSource(rssUrl);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            ByteArrayInputStream input = new ByteArrayInputStream(rssXml.getBytes("UTF-8"));
            org.w3c.dom.Document doc = builder.parse(input);
            doc.getDocumentElement().normalize();
            NodeList itemNodes = doc.getElementsByTagName("item");

            for (int i = 0; i < Math.min(itemNodes.getLength(), MAX_ITEMS); i++) {
                org.w3c.dom.Node itemNode = itemNodes.item(i);
                if (itemNode.getNodeType() == org.w3c.dom.Node.ELEMENT_NODE) {
                    org.w3c.dom.Element element = (org.w3c.dom.Element) itemNode;
                    System.out.println("Title: " + getElementValue(element, "title"));
                    System.out.println("Link: " + getElementValue(element, "link"));
                    System.out.println("Description: " + getElementValue(element, "description"));
                }
            }
        } catch (Exception e) {
            System.out.println("Error in retrieving RSS content for " + rssUrl + ": " + e.getMessage());
        }
    }

    private static String getElementValue(org.w3c.dom.Element parentElement, String tagName) {
        NodeList nodeList = parentElement.getElementsByTagName(tagName);
        if (nodeList.getLength() > 0) {
            return nodeList.item(0).getTextContent();
        }
        return "";
    }


    public static String extractRssUrl(String url) throws IOException {
        Document doc = Jsoup.connect(url).get();
        Elements rssLinks = doc.select("link[type=application/rss+xml]");
        if (!rssLinks.isEmpty()) {
            return rssLinks.attr("abs:href");
        }
        return "";
    }

    public static String fetchPageSource(String urlString) throws IOException {
        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36");
        StringBuilder content = new StringBuilder();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            String inputLine;
            while ((inputLine = reader.readLine()) != null) {
                content.append(inputLine);
            }
        }

        return content.toString();
    }
}

